# SApay Financial Core — Demo Only

A starter NestJS service demonstrating a double-entry ledger and wallet-to-wallet transfers using **in-memory storage**. It is deliberately disconnected from banks, payment processors, mobile-money providers, and real funds.

> **Important:** This is a local prototype, not a regulated payment product, not production-ready, and not authorization to provide financial services. Data disappears on restart. Do not use real personal, banking, or customer data.

## Requirements
- Node.js 20+ (Node 22 recommended)
- npm 10+

## Run locally
```bash
npm install
npm run start:dev
```
API: `http://localhost:3000`

Health:
```bash
curl http://localhost:3000/health
```

Create two demo wallets:
```bash
curl -X POST http://localhost:3000/demo/wallets \
  -H 'content-type: application/json' \
  -d '{"ownerId":"demo-user-a","currency":"SDG"}'

curl -X POST http://localhost:3000/demo/wallets \
  -H 'content-type: application/json' \
  -d '{"ownerId":"demo-user-b","currency":"SDG"}'
```
Copy the returned wallet IDs. Fund a wallet with **simulated** demo funds:
```bash
curl -X POST http://localhost:3000/demo/wallets/WALLET_ID/credit \
  -H 'content-type: application/json' \
  -d '{"amountMinor":"100000","reference":"demo-seed-001"}'
```
Amounts are integer minor units represented as strings to avoid floating-point rounding. For this demo, SDG minor-unit conventions are not asserted; use integer units only in tests. `credit` is a demo-only minting endpoint and must never exist in a live money system.

Transfer:
```bash
curl -X POST http://localhost:3000/transfers \
  -H 'content-type: application/json' \
  -H 'idempotency-key: demo-transfer-001' \
  -d '{"fromWalletId":"SOURCE_ID","toWalletId":"DEST_ID","amountMinor":"2500","currency":"SDG"}'
```
Get wallet:
```bash
curl http://localhost:3000/demo/wallets/WALLET_ID
```
View journal:
```bash
curl http://localhost:3000/ledger/journals
```

## Tests
```bash
npm test
npm run build
```

## Safety and architecture notes
- Double-entry postings are checked to balance per currency.
- Transfers reject zero/negative amounts, insufficient balance, currency mismatch, and self-transfers.
- Idempotency keys prevent duplicate successful transfers within this single process.
- The store is in-memory and operations are synchronous; this does **not** provide durable transactions, multi-instance concurrency safety, or crash recovery.
- The demo credit endpoint simulates funding. It is intentionally labelled demo-only.
- Before any real-money pilot, replace the store with PostgreSQL transactions/locking, durable unique idempotency records, authentication and authorization, rate limits, key management, reconciliation, monitoring, immutable audit storage, security review, disaster recovery, and all required regulatory approvals and partner integrations. Never simply expose this demo endpoint to the internet.

## PostgreSQL (database foundation)
```bash
cp .env.example .env
docker compose up -d postgres
```
Then start the API with `npm run start:dev`. Check the database connection at
`http://localhost:3000/api/database/health`. SQL schema is in `database/init/001_schema.sql`.

Wallet creation, simulated credits, transfers, ledger postings, balances, and idempotency are now written/read through PostgreSQL. Each transfer is committed in a single database transaction, locks the wallet rows in stable order, and stores the idempotency response durably. The original in-memory service remains only as legacy code and is no longer used by the API controllers.
