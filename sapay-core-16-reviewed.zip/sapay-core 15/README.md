# SApay Financial Core — Demo Only

A NestJS API for a **non-production demonstration** of wallets, a PostgreSQL-backed double-entry ledger, and wallet-to-wallet transfers.

> **Safety notice:** This prototype does not move real money, connect to banks, mobile-money providers, or payment processors, and does not represent a financial licence or regulatory approval. Do not use real customer, identity, or banking data. A production launch would require security, legal, regulatory, operational, and independent financial-ledger reviews.

## Requirements

- Docker Engine with the Docker Compose plugin, or Node.js 20+ and npm 10+
- PostgreSQL 16 if running the API outside Docker

## Start the full demo with Docker Compose

1. Copy `.env.example` to `.env`.
2. Replace `POSTGRES_PASSWORD` in `.env` with a strong, unique local password.
3. Start the services:

```bash
docker compose up -d --build
```

4. Check service status and API logs:

```bash
docker compose ps
docker compose logs --tail=100 api
```

5. Check the API and database:

```bash
curl http://localhost:3000/api/health
curl http://localhost:3000/api/database/health
```

The database health response should report `configured: true` and `reachable: true`.

**Existing data protection:** The Compose configuration retains the named volume `sapay_pgdata`. Do not run `docker compose down -v`, `docker volume rm`, or any database reset command. PostgreSQL initialization scripts in `database/init` run only when PostgreSQL initializes an empty data directory; they do not automatically modify an existing database.

## Run the API directly on your computer

Start PostgreSQL separately and set `DATABASE_URL` to point to it. Then:

```bash
npm install
npm run build
npm run start:dev
```

The API listens on `http://localhost:3000` and uses the global `/api` prefix.

## Demo API examples

Create two demo wallets:

```bash
curl -X POST http://localhost:3000/api/demo/wallets \
  -H 'content-type: application/json' \
  -d '{"ownerId":"demo-user-a","currency":"SDG"}'

curl -X POST http://localhost:3000/api/demo/wallets \
  -H 'content-type: application/json' \
  -d '{"ownerId":"demo-user-b","currency":"SDG"}'
```

Copy the returned wallet IDs. Credit a wallet with **simulated demo funds only**:

```bash
curl -X POST http://localhost:3000/api/demo/wallets/WALLET_ID/credit \
  -H 'content-type: application/json' \
  -d '{"amountMinor":"100000","reference":"demo-seed-001"}'
```

Transfer between the two demo wallets:

```bash
curl -X POST http://localhost:3000/api/transfers \
  -H 'content-type: application/json' \
  -H 'idempotency-key: demo-transfer-001' \
  -d '{"fromWalletId":"SOURCE_ID","toWalletId":"DEST_ID","amountMinor":"2500","currency":"SDG"}'
```

Get a wallet and view the journal:

```bash
curl http://localhost:3000/api/demo/wallets/WALLET_ID
curl http://localhost:3000/api/ledger/journals
```

Amounts are integer minor units represented as strings to avoid floating-point rounding. This demo does not assert Sudanese pound minor-unit conventions. The credit endpoint is simulated issuance and must never be exposed in a live money system.

## Tests and build

```bash
npm test
npm run build
```

## Architecture and remaining production requirements

- Wallet balances are derived from append-only ledger postings.
- Transfers use PostgreSQL transactions, wallet row locks, and persistent idempotency records.
- The API's in-memory `LedgerService` is legacy/demo unit-test code; HTTP controllers use `PostgresLedgerService`.
- No authentication, authorization, bank integrations, real funding, FX, regulatory controls, production observability, or disaster-recovery setup is included.
- Before any real-money pilot, obtain legal/regulatory advice and complete independent security, accounting, operational, and compliance reviews.
