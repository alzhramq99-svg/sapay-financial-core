import { Module } from '@nestjs/common';
import { LedgerModule } from './ledger/ledger.module';
import { DatabaseModule } from './database/database.module';
import { DatabaseController } from './database/database.controller';

@Module({
  imports: [DatabaseModule, LedgerModule],
  controllers: [DatabaseController],
})
export class AppModule {}
