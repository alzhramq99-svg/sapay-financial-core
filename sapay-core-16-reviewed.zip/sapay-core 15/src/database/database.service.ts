import { Injectable, Logger, OnModuleDestroy, OnModuleInit, ServiceUnavailableException } from '@nestjs/common';
import { Pool, PoolClient, QueryResult, QueryResultRow } from 'pg';

/**
 * PostgreSQL connection pool. This is the connection layer only.
 * The existing LedgerService remains in-memory until its repository is migrated.
 */
@Injectable()
export class DatabaseService implements OnModuleInit, OnModuleDestroy {
  private readonly logger = new Logger(DatabaseService.name);
  private pool?: Pool;

  async onModuleInit(): Promise<void> {
    const connectionString = process.env.DATABASE_URL;
    if (!connectionString) {
      this.logger.warn('DATABASE_URL is not set; PostgreSQL connection is disabled.');
      return;
    }
    this.pool = new Pool({
      connectionString,
      max: 10,
      connectionTimeoutMillis: 5000,
      idleTimeoutMillis: 30000,
      application_name: 'sapay-demo-api',
      ssl: process.env.DATABASE_SSL === 'true' ? { rejectUnauthorized: true } : undefined,
    });
    this.pool.on('error', (error) => this.logger.error(`PostgreSQL idle client error: ${error.message}`));
    await this.pool.query('SELECT 1');
    this.logger.log('PostgreSQL connection established (demo environment).');
  }

  async onModuleDestroy(): Promise<void> {
    await this.pool?.end();
  }

  get isConfigured(): boolean {
    return Boolean(this.pool);
  }

  async query<T extends QueryResultRow = QueryResultRow>(
    sql: string,
    params: unknown[] = [],
  ): Promise<QueryResult<T>> {
    if (!this.pool) {
      throw new ServiceUnavailableException('Database is not configured; set DATABASE_URL and start PostgreSQL');
    }
    return this.pool.query<T>(sql, params);
  }

  async withTransaction<T>(work: (client: PoolClient) => Promise<T>): Promise<T> {
    if (!this.pool) {
      throw new ServiceUnavailableException('Database is not configured; set DATABASE_URL and start PostgreSQL');
    }
    const client = await this.pool.connect();
    try {
      await client.query('BEGIN');
      const result = await work(client);
      await client.query('COMMIT');
      return result;
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }
  }

  async ping(): Promise<{ configured: boolean; reachable: boolean }> {
    if (!this.pool) return { configured: false, reachable: false };
    try {
      await this.pool.query('SELECT 1');
      return { configured: true, reachable: true };
    } catch {
      return { configured: true, reachable: false };
    }
  }
}
