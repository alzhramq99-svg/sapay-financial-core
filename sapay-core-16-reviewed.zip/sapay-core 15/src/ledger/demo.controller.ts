import { Body, Controller, Get, Param, Post } from '@nestjs/common';
import { PostgresLedgerService } from '../database/postgres-ledger.service';

@Controller('demo')
export class DemoController {
  constructor(private readonly ledger: PostgresLedgerService) {}

  @Post('wallets')
  createWallet(@Body() body: { ownerId: string; currency: string }) {
    return this.ledger.createWallet(body?.ownerId, body?.currency);
  }

  @Get('wallets')
  listWallets() {
    return this.ledger.listWallets();
  }

  @Get('wallets/:id')
  getWallet(@Param('id') id: string) {
    return this.ledger.getWallet(id);
  }

  @Post('wallets/:id/credit')
  demoCredit(
    @Param('id') id: string,
    @Body() body: { amountMinor: string; reference: string },
  ) {
    return this.ledger.demoCredit(id, body?.amountMinor, body?.reference);
  }
}
