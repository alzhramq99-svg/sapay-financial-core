import { Body, Controller, Get, Headers, Post } from '@nestjs/common';
import { PostgresLedgerService } from '../database/postgres-ledger.service';

@Controller()
export class LedgerController {
  constructor(private readonly ledger: PostgresLedgerService) {}

  @Get('health')
  health() {
    return {
      status: 'ok',
      mode: 'DEMO_ONLY',
      storage: 'postgresql',
      realMoneyEnabled: false,
      bankIntegrationsEnabled: false,
    };
  }

  @Post('transfers')
  transfer(
    @Headers('idempotency-key') idempotencyKey: string | undefined,
    @Body() body: { fromWalletId: string; toWalletId: string; amountMinor: string; currency: string },
  ) {
    return this.ledger.transfer({ ...body, idempotencyKey: idempotencyKey ?? '' });
  }

  @Get('ledger/journals')
  journals() {
    return this.ledger.listJournals();
  }
}
