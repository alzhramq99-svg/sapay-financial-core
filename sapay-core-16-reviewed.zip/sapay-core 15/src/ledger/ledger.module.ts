import { Module } from '@nestjs/common';
import { LedgerController } from './ledger.controller';
import { LedgerService } from './ledger.service';
import { DemoController } from './demo.controller';

@Module({
  controllers: [LedgerController, DemoController],
  providers: [LedgerService],
  exports: [LedgerService],
})
export class LedgerModule {}
